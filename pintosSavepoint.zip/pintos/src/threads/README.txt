Author: Casey Andres

NOTES:

1. Created Alarm-Mega.ck

2. Altered tests.c and tests.h and alarm-wait.c to  incorporate new tests by following set patterns within
